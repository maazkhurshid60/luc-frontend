<a href="#" onclick='showlogs(@json($properties))' class="btn btn-info btn-xs showlogs" > {{ __('Track Changes') }} </a>
