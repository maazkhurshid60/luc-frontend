<a href="{{ route('role.edit', $id) }}" class="btn btn-xs btn-blue"> {{ __('Edit') }} </a>
